import readline from "node:readline"
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
})
function containsOnlyDigits(str) {
    return /^\d+$/.test(str);
}

rl.question("Please input your name. Name: ", name => {
    console.log("Well hello, " + name + "!")
    run()
})
function run() {
    setTimeout(() => {
        rl.question("Please input a number. Number: ", number1 => {
            if (!containsOnlyDigits(number1)) {
                rl: close()
            }
            rl.question("Good. Now pick a math operator (+, -, *, /, ^, sin, cos, tan). Operator: ", operator => {
                switch (operator) {
                    case ("+"):
                        break
                    case ("-"):
                        break
                    case ("*"):
                        break
                    case ("/"):
                        break
                    case ("^"):
                        break
                    case ("sin"):
                        break
                    case ("cos"):
                        break
                    case ("tan"):
                        break
                    default:
                        rl: close()
                }
                switch (operator) {
                    case ("sin"):
                        console.log("You have made the expression " + number1 + operator + ".")
                        setTimeout(() => {
                            console.log("Calculating...")
                            setTimeout(() => {
                                let calculation = 0
                                switch (operator) {
                                    case ("+"):
                                        calculation = Number(number1) + Number(number2)
                                        break
                                    case ("-"):
                                        calculation = Number(number1) - Number(number2)
                                        break
                                    case ("*"):
                                        calculation = Number(number1) * Number(number2)
                                        break
                                    case ("/"):
                                        calculation = Number(number1) / Number(number2)
                                        break
                                    case ("^"):
                                        calculation = Math.pow(Number(number1), Number(number2))
                                        break
                                    case ("sin"):
                                        calculation = Math.sin(Number(number1))
                                        break
                                    case ("cos"):
                                        calculation = Math.cos(Number(number1))
                                        break
                                    case ("tan"):
                                        calculation = Math.tan(Number(number1))
                                        break
                                }
                                console.log("Calculation completed. Your output is " + calculation + ".")
                                setTimeout(() => {
                                    rl.question("Would you like to quit? Yes or no? ", answer => {
                                        if (answer != "No") {
                                            rl.close()
                                        } else {
                                            console.log("--------------------------------------------")
                                            return run()
                                        }
                                    })
                                }, 2000)
                            }, 2000)
                        }, 2000)
                        break
                    case ("cos"):
                        console.log("You have made the expression " + number1 + operator + ".")
                        setTimeout(() => {
                            console.log("Calculating...")
                            setTimeout(() => {
                                let calculation = 0
                                switch (operator) {
                                    case ("+"):
                                        calculation = Number(number1) + Number(number2)
                                        break
                                    case ("-"):
                                        calculation = Number(number1) - Number(number2)
                                        break
                                    case ("*"):
                                        calculation = Number(number1) * Number(number2)
                                        break
                                    case ("/"):
                                        calculation = Number(number1) / Number(number2)
                                        break
                                    case ("^"):
                                        calculation = Math.pow(Number(number1), Number(number2))
                                        break
                                    case ("sin"):
                                        calculation = Math.sin(Number(number1))
                                        break
                                    case ("cos"):
                                        calculation = Math.cos(Number(number1))
                                        break
                                    case ("tan"):
                                        calculation = Math.tan(Number(number1))
                                        break
                                }
                                console.log("Calculation completed. Your output is " + calculation + ".")
                                setTimeout(() => {
                                    rl.question("Would you like to quit? Yes or no? ", answer => {
                                        if (answer != "No") {
                                            rl.close()
                                        } else {
                                            console.log("--------------------------------------------")
                                            return run()
                                        }
                                    })
                                }, 2000)
                            }, 2000)
                        }, 2000)
                        break
                    case ("tan"):
                        console.log("You have made the expression " + number1 + operator + ".")
                        setTimeout(() => {
                            console.log("Calculating...")
                            setTimeout(() => {
                                let calculation = 0
                                switch (operator) {
                                    case ("+"):
                                        calculation = Number(number1) + Number(number2)
                                        break
                                    case ("-"):
                                        calculation = Number(number1) - Number(number2)
                                        break
                                    case ("*"):
                                        calculation = Number(number1) * Number(number2)
                                        break
                                    case ("/"):
                                        calculation = Number(number1) / Number(number2)
                                        break
                                    case ("^"):
                                        calculation = Math.pow(Number(number1), Number(number2))
                                        break
                                    case ("sin"):
                                        calculation = Math.sin(Number(number1))
                                        break
                                    case ("cos"):
                                        calculation = Math.cos(Number(number1))
                                        break
                                    case ("tan"):
                                        calculation = Math.tan(Number(number1))
                                        break
                                }
                                console.log("Calculation completed. Your output is " + calculation + ".")
                                setTimeout(() => {
                                    rl.question("Would you like to quit? Yes or no? ", answer => {
                                        if (answer != "No") {
                                            rl.close()
                                        } else {
                                            console.log("--------------------------------------------")
                                            return run()
                                        }
                                    })
                                }, 2000)
                            }, 2000)
                        }, 2000)
                        break
                    default:
                        rl.question("Please input a second number. Number: ", number2 => {
                            console.log("You have made the expression " + number1 + operator + number2 + ".")
                            setTimeout(() => {
                                console.log("Calculating...")
                                setTimeout(() => {
                                    let calculation = 0
                                    switch (operator) {
                                        case ("+"):
                                            calculation = Number(number1) + Number(number2)
                                            break
                                        case ("-"):
                                            calculation = Number(number1) - Number(number2)
                                            break
                                        case ("*"):
                                            calculation = Number(number1) * Number(number2)
                                            break
                                        case ("/"):
                                            calculation = Number(number1) / Number(number2)
                                            break
                                        case ("^"):
                                            calculation = Math.pow(Number(number1), Number(number2))
                                            break
                                        case ("sin"):
                                            calculation = Math.sin(Number(number1))
                                            break
                                        case ("cos"):
                                            calculation = Math.cos(Number(number1))
                                            break
                                        case ("tan"):
                                            calculation = Math.tan(Number(number1))
                                            break
                                    }
                                    console.log("Calculation completed. Your output is " + calculation + ".")
                                    setTimeout(() => {
                                        rl.question("Would you like to quit? Yes or no? ", answer => {
                                            if (answer != "No") {
                                                rl.close()
                                            } else {
                                                console.log("--------------------------------------------")
                                                return run()
                                            }
                                        })
                                    }, 2000)
                                }, 2000)
                            }, 2000)
                        })
                        break
                }
            })

        })
    }, 2000)
}
run()