# Calculator


Hello! Welcome to Payton's Calculator.
In here you are able to calculate 5 functions as of now.
Addition, Subtraction, Multiplication, Division, and Exponents.
I have tested each function, and they all work.
To start, enter your name.
Then input a number.
Any number.
Now type a function (+, -, *, /, ^, sin, cos, tan).
Now type another number.
The program will then compute the expression.
I hope you have a good time using this!